<?php 
$pagina = 'despesas';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';
$campo2 = 'Categoria';


 ?>