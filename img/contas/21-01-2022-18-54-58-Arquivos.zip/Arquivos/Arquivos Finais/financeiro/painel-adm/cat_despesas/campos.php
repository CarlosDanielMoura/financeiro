<?php 
$pagina = 'cat_despesas';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';

 ?>