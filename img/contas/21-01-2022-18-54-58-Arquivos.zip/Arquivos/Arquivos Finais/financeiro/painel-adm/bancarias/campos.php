<?php 
$pagina = 'bancarias';
//VARIAVEIS DOS INPUTS
$campo1 = 'Banco';
$campo2 = 'Agencia';
$campo3 = 'Conta';
$campo4 = 'Tipo';
$campo5 = 'Pessoa';
$campo6 = 'Doc';
 ?>