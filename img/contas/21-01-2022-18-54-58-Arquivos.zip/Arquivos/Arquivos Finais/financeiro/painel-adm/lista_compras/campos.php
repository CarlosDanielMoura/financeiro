<?php 
$pagina = 'lista_compras';
//VARIAVEIS DOS INPUTS
$campo1 = 'Valor';
$campo2 = 'usuario';
$campo3 = 'Pagamento';
$campo4 = 'lancamento';
$campo5 = 'data_lanc';
$campo6 = 'data_pgto';
$campo10 = 'Parcelas';
$campo11 = 'Status';
$campo12 = 'Cliente';
 ?>