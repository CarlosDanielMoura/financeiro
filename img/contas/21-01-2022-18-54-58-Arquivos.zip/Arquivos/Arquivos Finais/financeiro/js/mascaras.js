$(document).ready(function () {
    $('#Telefone').mask('(00) 00000-0000');
    $('#Cpf').mask('000.000.000-00');
    $('#Cep').mask('00000-000');
    $('#Cnpj').mask('00.000.000/0000-00');

});