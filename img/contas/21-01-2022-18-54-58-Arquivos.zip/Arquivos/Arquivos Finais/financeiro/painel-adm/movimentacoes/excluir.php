<?php 
require_once("../../conexao.php");
$pagina = 'movimentacoes';
require_once("../rotinas/excluir_por_admin.php");

 ?>