<?php 
$pagina = 'produtos';
//VARIAVEIS DOS INPUTS
$campo1 = 'Codigo';
$campo2 = 'Nome';
$campo3 = 'Descricao';
$campo4 = 'Estoque';
$campo5 = 'Valor_Compra';
$campo6 = 'Valor_Venda';
$campo7 = 'Fornecedor';
$campo8 = 'Categoria';
$campo9 = 'Foto';
$campo10 = 'Ativo';
$campo11 = 'Lucro';
 ?>