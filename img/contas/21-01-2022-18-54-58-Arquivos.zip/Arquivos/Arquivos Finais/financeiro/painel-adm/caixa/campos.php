<?php 
$pagina = 'caixa';
//VARIAVEIS DOS INPUTS
$campo1 = 'data_ab';
$campo2 = 'valor_ab';
$campo3 = 'usuario_ab';
$campo4 = 'data_fec';

$campo6 = 'usuario_fec';
$campo7 = 'Saldo';
$campo8 = 'Status';
 ?>