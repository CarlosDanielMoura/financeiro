<?php 
$pagina = 'bancos';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';

 ?>